/****************************************************************************
** Meta object code from reading C++ file 'diggingdashboard.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.12.4)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include "../../DiggingDashboard/diggingdashboard.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'diggingdashboard.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.12.4. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_DiggingDashboard_t {
    QByteArrayData data[42];
    char stringdata0[430];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_DiggingDashboard_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_DiggingDashboard_t qt_meta_stringdata_DiggingDashboard = {
    {
QT_MOC_LITERAL(0, 0, 16), // "DiggingDashboard"
QT_MOC_LITERAL(1, 17, 13), // "serialConnect"
QT_MOC_LITERAL(2, 31, 0), // ""
QT_MOC_LITERAL(3, 32, 12), // "repollSerial"
QT_MOC_LITERAL(4, 45, 14), // "serialReceived"
QT_MOC_LITERAL(5, 60, 12), // "startDigging"
QT_MOC_LITERAL(6, 73, 17), // "startConstDigging"
QT_MOC_LITERAL(7, 91, 11), // "stopDigging"
QT_MOC_LITERAL(8, 103, 13), // "raiseElevator"
QT_MOC_LITERAL(9, 117, 13), // "lowerElevator"
QT_MOC_LITERAL(10, 131, 6), // "upFast"
QT_MOC_LITERAL(11, 138, 8), // "downFast"
QT_MOC_LITERAL(12, 147, 8), // "peckLong"
QT_MOC_LITERAL(13, 156, 9), // "peckShort"
QT_MOC_LITERAL(14, 166, 4), // "bite"
QT_MOC_LITERAL(15, 171, 9), // "slowAuger"
QT_MOC_LITERAL(16, 181, 9), // "spinAuger"
QT_MOC_LITERAL(17, 191, 9), // "stopAuger"
QT_MOC_LITERAL(18, 201, 10), // "setLogging"
QT_MOC_LITERAL(19, 212, 7), // "sendCmd"
QT_MOC_LITERAL(20, 220, 11), // "secureAuger"
QT_MOC_LITERAL(21, 232, 12), // "releaseAuger"
QT_MOC_LITERAL(22, 245, 15), // "initElevatorPos"
QT_MOC_LITERAL(23, 261, 9), // "RCDigging"
QT_MOC_LITERAL(24, 271, 6), // "simDig"
QT_MOC_LITERAL(25, 278, 6), // "simSet"
QT_MOC_LITERAL(26, 285, 7), // "r0Moved"
QT_MOC_LITERAL(27, 293, 7), // "r1Moved"
QT_MOC_LITERAL(28, 301, 7), // "c0Moved"
QT_MOC_LITERAL(29, 309, 7), // "c1Moved"
QT_MOC_LITERAL(30, 317, 8), // "wobMoved"
QT_MOC_LITERAL(31, 326, 6), // "xMoved"
QT_MOC_LITERAL(32, 333, 6), // "yMoved"
QT_MOC_LITERAL(33, 340, 6), // "zMoved"
QT_MOC_LITERAL(34, 347, 12), // "deepestMoved"
QT_MOC_LITERAL(35, 360, 8), // "mstMoved"
QT_MOC_LITERAL(36, 369, 8), // "strMoved"
QT_MOC_LITERAL(37, 378, 9), // "progMoved"
QT_MOC_LITERAL(38, 388, 9), // "timerTick"
QT_MOC_LITERAL(39, 398, 8), // "setAdapt"
QT_MOC_LITERAL(40, 407, 11), // "setConstant"
QT_MOC_LITERAL(41, 419, 10) // "setSurface"

    },
    "DiggingDashboard\0serialConnect\0\0"
    "repollSerial\0serialReceived\0startDigging\0"
    "startConstDigging\0stopDigging\0"
    "raiseElevator\0lowerElevator\0upFast\0"
    "downFast\0peckLong\0peckShort\0bite\0"
    "slowAuger\0spinAuger\0stopAuger\0setLogging\0"
    "sendCmd\0secureAuger\0releaseAuger\0"
    "initElevatorPos\0RCDigging\0simDig\0"
    "simSet\0r0Moved\0r1Moved\0c0Moved\0c1Moved\0"
    "wobMoved\0xMoved\0yMoved\0zMoved\0"
    "deepestMoved\0mstMoved\0strMoved\0progMoved\0"
    "timerTick\0setAdapt\0setConstant\0"
    "setSurface"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DiggingDashboard[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
      40,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       0,       // signalCount

 // slots: name, argc, parameters, tag, flags
       1,    0,  214,    2, 0x08 /* Private */,
       3,    0,  215,    2, 0x08 /* Private */,
       4,    0,  216,    2, 0x08 /* Private */,
       5,    0,  217,    2, 0x08 /* Private */,
       6,    0,  218,    2, 0x08 /* Private */,
       7,    0,  219,    2, 0x08 /* Private */,
       8,    0,  220,    2, 0x08 /* Private */,
       9,    0,  221,    2, 0x08 /* Private */,
      10,    0,  222,    2, 0x08 /* Private */,
      11,    0,  223,    2, 0x08 /* Private */,
      12,    0,  224,    2, 0x08 /* Private */,
      13,    0,  225,    2, 0x08 /* Private */,
      14,    0,  226,    2, 0x08 /* Private */,
      15,    0,  227,    2, 0x08 /* Private */,
      16,    0,  228,    2, 0x08 /* Private */,
      17,    0,  229,    2, 0x08 /* Private */,
      18,    0,  230,    2, 0x08 /* Private */,
      19,    0,  231,    2, 0x08 /* Private */,
      20,    0,  232,    2, 0x08 /* Private */,
      21,    0,  233,    2, 0x08 /* Private */,
      22,    0,  234,    2, 0x08 /* Private */,
      23,    0,  235,    2, 0x08 /* Private */,
      24,    0,  236,    2, 0x08 /* Private */,
      25,    0,  237,    2, 0x08 /* Private */,
      26,    0,  238,    2, 0x08 /* Private */,
      27,    0,  239,    2, 0x08 /* Private */,
      28,    0,  240,    2, 0x08 /* Private */,
      29,    0,  241,    2, 0x08 /* Private */,
      30,    0,  242,    2, 0x08 /* Private */,
      31,    0,  243,    2, 0x08 /* Private */,
      32,    0,  244,    2, 0x08 /* Private */,
      33,    0,  245,    2, 0x08 /* Private */,
      34,    0,  246,    2, 0x08 /* Private */,
      35,    0,  247,    2, 0x08 /* Private */,
      36,    0,  248,    2, 0x08 /* Private */,
      37,    0,  249,    2, 0x08 /* Private */,
      38,    0,  250,    2, 0x08 /* Private */,
      39,    0,  251,    2, 0x08 /* Private */,
      40,    0,  252,    2, 0x08 /* Private */,
      41,    0,  253,    2, 0x08 /* Private */,

 // slots: parameters
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,
    QMetaType::Void,

       0        // eod
};

void DiggingDashboard::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<DiggingDashboard *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->serialConnect(); break;
        case 1: _t->repollSerial(); break;
        case 2: _t->serialReceived(); break;
        case 3: _t->startDigging(); break;
        case 4: _t->startConstDigging(); break;
        case 5: _t->stopDigging(); break;
        case 6: _t->raiseElevator(); break;
        case 7: _t->lowerElevator(); break;
        case 8: _t->upFast(); break;
        case 9: _t->downFast(); break;
        case 10: _t->peckLong(); break;
        case 11: _t->peckShort(); break;
        case 12: _t->bite(); break;
        case 13: _t->slowAuger(); break;
        case 14: _t->spinAuger(); break;
        case 15: _t->stopAuger(); break;
        case 16: _t->setLogging(); break;
        case 17: _t->sendCmd(); break;
        case 18: _t->secureAuger(); break;
        case 19: _t->releaseAuger(); break;
        case 20: _t->initElevatorPos(); break;
        case 21: _t->RCDigging(); break;
        case 22: _t->simDig(); break;
        case 23: _t->simSet(); break;
        case 24: _t->r0Moved(); break;
        case 25: _t->r1Moved(); break;
        case 26: _t->c0Moved(); break;
        case 27: _t->c1Moved(); break;
        case 28: _t->wobMoved(); break;
        case 29: _t->xMoved(); break;
        case 30: _t->yMoved(); break;
        case 31: _t->zMoved(); break;
        case 32: _t->deepestMoved(); break;
        case 33: _t->mstMoved(); break;
        case 34: _t->strMoved(); break;
        case 35: _t->progMoved(); break;
        case 36: _t->timerTick(); break;
        case 37: _t->setAdapt(); break;
        case 38: _t->setConstant(); break;
        case 39: _t->setSurface(); break;
        default: ;
        }
    }
    Q_UNUSED(_a);
}

QT_INIT_METAOBJECT const QMetaObject DiggingDashboard::staticMetaObject = { {
    &QMainWindow::staticMetaObject,
    qt_meta_stringdata_DiggingDashboard.data,
    qt_meta_data_DiggingDashboard,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *DiggingDashboard::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DiggingDashboard::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_DiggingDashboard.stringdata0))
        return static_cast<void*>(this);
    return QMainWindow::qt_metacast(_clname);
}

int DiggingDashboard::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QMainWindow::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 40)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 40;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 40)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 40;
    }
    return _id;
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
